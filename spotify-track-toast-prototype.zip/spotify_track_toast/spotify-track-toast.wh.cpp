// ==WindhawkMod==
// @id              spotify-track-toast
// @name            Spotify Track Toast
// @description     Show a small album-art notification when Spotify changes tracks.
// @version         0.1.0
// @author          OpenAI
// @include         explorer.exe
// @compilerOptions -lgdi32 -luser32 -lole32 -lwindowscodecs -lwindowsapp -luuid
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# Spotify Track Toast (prototype)

Shows a compact notification in a screen corner when a new Spotify track starts.
The notification contains album art, track title, and artist, and hides automatically.

This first version reads Spotify playback information from Windows System Media Transport Controls.
It does not require a Spotify API key or access token.

Default: top-right corner, visible for 2 seconds.
*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- DurationSeconds: 2
  $name: Display duration
  $description: How many seconds the notification stays visible (1-8).
- Corner: top-right
  $name: Screen corner
  $options:
  - top-right: Top right
  - top-left: Top left
  - bottom-right: Bottom right
  - bottom-left: Bottom left
*/
// ==/WindhawkModSettings==

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincodec.h>

#undef GetCurrentTime
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Storage.Streams.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <memory>
#include <new>
#include <string>
#include <vector>
#include <cwctype>

namespace {

constexpr wchar_t kWindowClassName[] = L"WindhawkSpotifyTrackToastWindow";
constexpr UINT kNewTrackMessage = WM_APP + 0x39;
constexpr UINT_PTR kHideTimerId = 1;
constexpr int kToastWidth = 410;
constexpr int kToastHeight = 108;
constexpr int kScreenMargin = 18;

HANDLE g_stopEvent = nullptr;
HANDLE g_uiThread = nullptr;
std::atomic<HWND> g_hwnd{nullptr};
int g_durationSeconds = 2;
int g_corner = 0;  // 0=top-right, 1=top-left, 2=bottom-right, 3=bottom-left

std::wstring g_title;
std::wstring g_artist;
HBITMAP g_cover = nullptr;

struct TrackPayload {
    std::wstring title;
    std::wstring artist;
    HBITMAP cover = nullptr;
};

void DestroyPayload(TrackPayload* payload) {
    if (!payload) {
        return;
    }
    if (payload->cover) {
        DeleteObject(payload->cover);
        payload->cover = nullptr;
    }
    delete payload;
}

void LoadSettings() {
    g_durationSeconds = std::clamp(Wh_GetIntSetting(L"DurationSeconds"), 1, 8);
    g_corner = 0;

    PCWSTR corner = Wh_GetStringSetting(L"Corner");
    if (corner) {
        if (wcscmp(corner, L"top-left") == 0) {
            g_corner = 1;
        } else if (wcscmp(corner, L"bottom-right") == 0) {
            g_corner = 2;
        } else if (wcscmp(corner, L"bottom-left") == 0) {
            g_corner = 3;
        }
        Wh_FreeStringSetting(corner);
    }
}

HBITMAP DecodeImageToBitmap(const std::vector<uint8_t>& bytes) {
    if (bytes.empty() || bytes.size() > 16u * 1024u * 1024u) {
        return nullptr;
    }

    IWICImagingFactory* factory = nullptr;
    IWICStream* imageStream = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICFormatConverter* converter = nullptr;
    HBITMAP bitmap = nullptr;

    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr,
                                  CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory));
    if (SUCCEEDED(hr)) {
        hr = factory->CreateStream(&imageStream);
    }
    if (SUCCEEDED(hr)) {
        hr = imageStream->InitializeFromMemory(
            const_cast<BYTE*>(reinterpret_cast<const BYTE*>(bytes.data())),
            static_cast<DWORD>(bytes.size()));
    }
    if (SUCCEEDED(hr)) {
        hr = factory->CreateDecoderFromStream(
            imageStream, nullptr, WICDecodeMetadataCacheOnLoad, &decoder);
    }
    if (SUCCEEDED(hr)) {
        hr = decoder->GetFrame(0, &frame);
    }
    if (SUCCEEDED(hr)) {
        hr = factory->CreateFormatConverter(&converter);
    }
    if (SUCCEEDED(hr)) {
        hr = converter->Initialize(frame, GUID_WICPixelFormat32bppBGRA,
                                   WICBitmapDitherTypeNone, nullptr, 0.0,
                                   WICBitmapPaletteTypeCustom);
    }

    UINT width = 0;
    UINT height = 0;
    if (SUCCEEDED(hr)) {
        hr = converter->GetSize(&width, &height);
    }
    if (SUCCEEDED(hr) && width > 0 && height > 0 && width <= 8192 && height <= 8192) {
        BITMAPINFO bitmapInfo{};
        bitmapInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bitmapInfo.bmiHeader.biWidth = static_cast<LONG>(width);
        bitmapInfo.bmiHeader.biHeight = -static_cast<LONG>(height);  // top-down DIB
        bitmapInfo.bmiHeader.biPlanes = 1;
        bitmapInfo.bmiHeader.biBitCount = 32;
        bitmapInfo.bmiHeader.biCompression = BI_RGB;

        void* pixels = nullptr;
        HDC screenDc = GetDC(nullptr);
        bitmap = CreateDIBSection(screenDc, &bitmapInfo, DIB_RGB_COLORS,
                                  &pixels, nullptr, 0);
        ReleaseDC(nullptr, screenDc);

        if (!bitmap || !pixels) {
            if (bitmap) {
                DeleteObject(bitmap);
            }
            bitmap = nullptr;
        } else {
            const UINT stride = width * 4;
            const UINT bufferSize = stride * height;
            hr = converter->CopyPixels(nullptr, stride, bufferSize,
                                       static_cast<BYTE*>(pixels));
            if (FAILED(hr)) {
                DeleteObject(bitmap);
                bitmap = nullptr;
            }
        }
    }

    if (converter) converter->Release();
    if (frame) frame->Release();
    if (decoder) decoder->Release();
    if (imageStream) imageStream->Release();
    if (factory) factory->Release();
    return bitmap;
}

HBITMAP GetAlbumCover(
    const winrt::Windows::Media::Control::GlobalSystemMediaTransportControlsSessionMediaProperties& properties) {
    try {
        auto thumbnail = properties.Thumbnail();
        if (!thumbnail) {
            return nullptr;
        }

        auto stream = thumbnail.OpenReadAsync().get();
        const uint64_t streamSize = stream.Size();
        if (streamSize == 0 || streamSize > 16u * 1024u * 1024u) {
            stream.Close();
            return nullptr;
        }

        winrt::Windows::Storage::Streams::DataReader reader(stream);
        reader.LoadAsync(static_cast<uint32_t>(streamSize)).get();
        std::vector<uint8_t> bytes(static_cast<size_t>(streamSize));
        reader.ReadBytes(bytes);
        reader.Close();
        stream.Close();

        return DecodeImageToBitmap(bytes);
    } catch (...) {
        return nullptr;
    }
}

winrt::Windows::Media::Control::GlobalSystemMediaTransportControlsSession
FindPlayingSpotifySession(
    const winrt::Windows::Media::Control::GlobalSystemMediaTransportControlsSessionManager& manager) {
    using namespace winrt::Windows::Media::Control;

    for (const auto& session : manager.GetSessions()) {
        try {
            std::wstring appId = session.SourceAppUserModelId().c_str();
            std::transform(appId.begin(), appId.end(), appId.begin(),
                           [](wchar_t ch) { return static_cast<wchar_t>(towlower(ch)); });
            if (appId.find(L"spotify") == std::wstring::npos) {
                continue;
            }

            const auto playbackInfo = session.GetPlaybackInfo();
            if (playbackInfo.PlaybackStatus() ==
                GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing) {
                return session;
            }
        } catch (...) {
            // Ignore a media session that disappears while it is being queried.
        }
    }

    return nullptr;
}

DWORD WINAPI MediaThreadProc(void*) {
    bool apartmentInitialized = false;
    try {
        winrt::init_apartment(winrt::apartment_type::multi_threaded);
        apartmentInitialized = true;

        auto manager = winrt::Windows::Media::Control::
            GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
        std::wstring lastTrackKey;

        while (WaitForSingleObject(g_stopEvent, 750) != WAIT_OBJECT_0) {
            try {
                auto session = FindPlayingSpotifySession(manager);
                if (!session) {
                    lastTrackKey.clear();
                    continue;
                }

                auto properties = session.TryGetMediaPropertiesAsync().get();
                std::wstring title = properties.Title().c_str();
                std::wstring artist = properties.Artist().c_str();
                if (title.empty() && artist.empty()) {
                    continue;
                }

                const std::wstring trackKey = title + L"\x1f" + artist;
                if (trackKey == lastTrackKey) {
                    continue;
                }
                lastTrackKey = trackKey;

                auto payload = new (std::nothrow) TrackPayload;
                if (!payload) {
                    continue;
                }
                payload->title = std::move(title);
                payload->artist = std::move(artist);
                payload->cover = GetAlbumCover(properties);

                HWND hwnd = g_hwnd.load();
                if (!hwnd || !PostMessageW(hwnd, kNewTrackMessage, 0,
                                           reinterpret_cast<LPARAM>(payload))) {
                    DestroyPayload(payload);
                }
            } catch (const winrt::hresult_error& error) {
                Wh_Log(L"Spotify Track Toast: media query failed (0x%08X)",
                       static_cast<unsigned int>(error.code()));
            } catch (...) {
                // A single failed query should not stop the monitor loop.
            }
        }

        manager = nullptr;
    } catch (const winrt::hresult_error& error) {
        Wh_Log(L"Spotify Track Toast: couldn't initialize media access (0x%08X)",
               static_cast<unsigned int>(error.code()));
    } catch (...) {
        Wh_Log(L"Spotify Track Toast: media monitor stopped unexpectedly");
    }

    if (apartmentInitialized) {
        winrt::uninit_apartment();
    }
    return 0;
}

void PositionToast(HWND hwnd) {
    POINT origin{0, 0};
    HMONITOR monitor = MonitorFromPoint(origin, MONITOR_DEFAULTTOPRIMARY);
    MONITORINFO monitorInfo{};
    monitorInfo.cbSize = sizeof(monitorInfo);
    RECT workArea{0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)};
    if (monitor && GetMonitorInfoW(monitor, &monitorInfo)) {
        workArea = monitorInfo.rcWork;
    }

    const bool left = (g_corner == 1 || g_corner == 3);
    const bool bottom = (g_corner == 2 || g_corner == 3);
    const int x = left ? workArea.left + kScreenMargin
                       : workArea.right - kToastWidth - kScreenMargin;
    const int y = bottom ? workArea.bottom - kToastHeight - kScreenMargin
                         : workArea.top + kScreenMargin;

    SetWindowPos(hwnd, HWND_TOPMOST, x, y, kToastWidth, kToastHeight,
                 SWP_NOACTIVATE | SWP_SHOWWINDOW);
    ShowWindow(hwnd, SW_SHOWNOACTIVATE);
}

void DrawToast(HDC dc) {
    RECT client{0, 0, kToastWidth, kToastHeight};
    HBRUSH background = CreateSolidBrush(RGB(24, 25, 29));
    FillRect(dc, &client, background);
    DeleteObject(background);

    SetBkMode(dc, TRANSPARENT);

    if (g_cover) {
        BITMAP bitmapInfo{};
        if (GetObjectW(g_cover, sizeof(bitmapInfo), &bitmapInfo)) {
            HDC memoryDc = CreateCompatibleDC(dc);
            if (memoryDc) {
                HGDIOBJ oldBitmap = SelectObject(memoryDc, g_cover);
                SetStretchBltMode(dc, HALFTONE);
                StretchBlt(dc, 13, 13, 82, 82, memoryDc, 0, 0,
                           bitmapInfo.bmWidth, bitmapInfo.bmHeight, SRCCOPY);
                SelectObject(memoryDc, oldBitmap);
                DeleteDC(memoryDc);
            }
        }
    } else {
        RECT coverRect{13, 13, 95, 95};
        HBRUSH placeholder = CreateSolidBrush(RGB(42, 45, 49));
        FillRect(dc, &coverRect, placeholder);
        DeleteObject(placeholder);

        HFONT noteFont = CreateFontW(-34, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                     DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                     CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                     DEFAULT_PITCH, L"Segoe UI Symbol");
        HGDIOBJ oldFont = SelectObject(dc, noteFont);
        SetTextColor(dc, RGB(30, 215, 96));
        DrawTextW(dc, L"♪", -1, &coverRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        SelectObject(dc, oldFont);
        DeleteObject(noteFont);
    }

    HBRUSH accent = CreateSolidBrush(RGB(30, 215, 96));
    RECT dotRect{111, 17, 119, 25};
    FillRect(dc, &dotRect, accent);
    DeleteObject(accent);

    HFONT headerFont = CreateFontW(-11, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                   CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                   DEFAULT_PITCH, L"Segoe UI");
    HFONT titleFont = CreateFontW(-17, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                                  DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                  CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                  DEFAULT_PITCH, L"Segoe UI");
    HFONT artistFont = CreateFontW(-13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                   CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                   DEFAULT_PITCH, L"Segoe UI");

    RECT headerRect{128, 12, kToastWidth - 14, 30};
    RECT titleRect{110, 34, kToastWidth - 14, 59};
    RECT artistRect{110, 61, kToastWidth - 14, 83};

    SetTextColor(dc, RGB(30, 215, 96));
    HGDIOBJ oldFont = SelectObject(dc, headerFont);
    DrawTextW(dc, L"SPOTIFY  |  NOW PLAYING", -1, &headerRect,
              DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    SetTextColor(dc, RGB(248, 248, 250));
    SelectObject(dc, titleFont);
    DrawTextW(dc, g_title.c_str(), -1, &titleRect,
              DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    SetTextColor(dc, RGB(177, 180, 187));
    SelectObject(dc, artistFont);
    DrawTextW(dc, g_artist.empty() ? L"Unknown artist" : g_artist.c_str(), -1,
              &artistRect, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    SelectObject(dc, oldFont);
    DeleteObject(artistFont);
    DeleteObject(titleFont);
    DeleteObject(headerFont);
}

LRESULT CALLBACK ToastWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case kNewTrackMessage: {
            std::unique_ptr<TrackPayload> payload(reinterpret_cast<TrackPayload*>(lParam));
            if (!payload) {
                return 0;
            }

            if (g_cover) {
                DeleteObject(g_cover);
            }
            g_cover = payload->cover;
            payload->cover = nullptr;
            g_title = std::move(payload->title);
            g_artist = std::move(payload->artist);

            InvalidateRect(hwnd, nullptr, TRUE);
            PositionToast(hwnd);
            KillTimer(hwnd, kHideTimerId);
            SetTimer(hwnd, kHideTimerId, static_cast<UINT>(g_durationSeconds * 1000), nullptr);
            return 0;
        }
        case WM_TIMER:
            if (wParam == kHideTimerId) {
                KillTimer(hwnd, kHideTimerId);
                ShowWindow(hwnd, SW_HIDE);
                return 0;
            }
            break;
        case WM_PAINT: {
            PAINTSTRUCT paint{};
            HDC dc = BeginPaint(hwnd, &paint);
            DrawToast(dc);
            EndPaint(hwnd, &paint);
            return 0;
        }
        case WM_ERASEBKGND:
            return 1;
        case WM_NCHITTEST:
            return HTTRANSPARENT;  // notification doesn't steal clicks
        case WM_CLOSE:
            if (g_stopEvent) {
                SetEvent(g_stopEvent);
            }
            return 0;
        case WM_DESTROY:
            KillTimer(hwnd, kHideTimerId);
            return 0;
    }

    return DefWindowProcW(hwnd, message, wParam, lParam);
}

DWORD WINAPI UiThreadProc(void*) {
    HINSTANCE instance = GetModuleHandleW(nullptr);
    WNDCLASSEXW windowClass{};
    windowClass.cbSize = sizeof(windowClass);
    windowClass.lpfnWndProc = ToastWndProc;
    windowClass.hInstance = instance;
    windowClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    windowClass.lpszClassName = kWindowClassName;
    windowClass.hbrBackground = nullptr;

    const ATOM classAtom = RegisterClassExW(&windowClass);
    const bool registeredHere = classAtom != 0;
    if (!registeredHere && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
        Wh_Log(L"Spotify Track Toast: failed to register notification window");
        return 1;
    }

    HWND hwnd = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE,
        kWindowClassName, L"Spotify Track Toast", WS_POPUP,
        0, 0, kToastWidth, kToastHeight, nullptr, nullptr, instance, nullptr);
    if (!hwnd) {
        Wh_Log(L"Spotify Track Toast: failed to create notification window");
        if (registeredHere) {
            UnregisterClassW(kWindowClassName, instance);
        }
        return 1;
    }

    SetLayeredWindowAttributes(hwnd, 0, 245, LWA_ALPHA);
    HRGN region = CreateRoundRectRgn(0, 0, kToastWidth + 1, kToastHeight + 1, 18, 18);
    if (region && !SetWindowRgn(hwnd, region, TRUE)) {
        DeleteObject(region);
    }
    g_hwnd.store(hwnd);

    HANDLE mediaThread = nullptr;
    if (WaitForSingleObject(g_stopEvent, 0) != WAIT_OBJECT_0) {
        mediaThread = CreateThread(nullptr, 0, MediaThreadProc, nullptr, 0, nullptr);
        if (!mediaThread) {
            Wh_Log(L"Spotify Track Toast: failed to start media monitor");
        }
    }

    while (WaitForSingleObject(g_stopEvent, 0) != WAIT_OBJECT_0) {
        const DWORD waitResult = MsgWaitForMultipleObjects(
            1, &g_stopEvent, FALSE, INFINITE, QS_ALLINPUT);
        if (waitResult == WAIT_OBJECT_0) {
            break;
        }
        if (waitResult != WAIT_OBJECT_0 + 1) {
            break;
        }

        MSG message{};
        while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE)) {
            if (message.message == WM_QUIT) {
                SetEvent(g_stopEvent);
                break;
            }
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }

    if (mediaThread) {
        WaitForSingleObject(mediaThread, INFINITE);
        CloseHandle(mediaThread);
    }

    // The media thread may have queued one last track while shutdown started.
    MSG pending{};
    while (PeekMessageW(&pending, nullptr, kNewTrackMessage,
                        kNewTrackMessage, PM_REMOVE)) {
        DestroyPayload(reinterpret_cast<TrackPayload*>(pending.lParam));
    }

    DestroyWindow(hwnd);
    g_hwnd.store(nullptr);
    if (g_cover) {
        DeleteObject(g_cover);
        g_cover = nullptr;
    }
    g_title.clear();
    g_artist.clear();

    if (registeredHere) {
        UnregisterClassW(kWindowClassName, instance);
    }
    return 0;
}

}  // namespace

BOOL Wh_ModInit() {
    LoadSettings();
    g_stopEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!g_stopEvent) {
        return FALSE;
    }

    g_uiThread = CreateThread(nullptr, 0, UiThreadProc, nullptr, 0, nullptr);
    if (!g_uiThread) {
        CloseHandle(g_stopEvent);
        g_stopEvent = nullptr;
        return FALSE;
    }
    return TRUE;
}

void Wh_ModUninit() {
    if (g_stopEvent) {
        SetEvent(g_stopEvent);
    }
    if (g_uiThread) {
        WaitForSingleObject(g_uiThread, INFINITE);
        CloseHandle(g_uiThread);
        g_uiThread = nullptr;
    }
    if (g_stopEvent) {
        CloseHandle(g_stopEvent);
        g_stopEvent = nullptr;
    }
}

BOOL Wh_ModSettingsChanged(BOOL* bReload) {
    if (bReload) {
        *bReload = TRUE;
    }
    return TRUE;
}
